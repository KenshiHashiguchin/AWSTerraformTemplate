# frozen_string_literal: true

### Install ###
execute 'curl -sL https://inspector-agent.amazonaws.com/linux/latest/install | bash -' do
  not_if '/opt/aws/awsagent/bin/awsagent status > /dev/null'
end
