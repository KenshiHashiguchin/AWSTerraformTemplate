# frozen_string_literal: true

### Dependencies ###
package 'ruby'

### Install ###
execute 'curl -sL https://aws-codedeploy-ap-northeast-1.s3.amazonaws.com/latest/install | ruby - auto' do
  not_if 'service codedeploy-agent status > /dev/null'
end

### Service ###
service 'codedeploy-agent' do
  action %i[enable start]
end
