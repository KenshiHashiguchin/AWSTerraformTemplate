# frozen_string_literal: true

### SSH ###
remote_file '/home/ec2-user/.ssh/config' do
  mode '0600'
  owner 'ec2-user'
  group 'ec2-user'
end
