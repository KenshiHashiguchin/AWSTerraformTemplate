# frozen_string_literal: true

### Install ###
package 'https://yum.newrelic.com/pub/newrelic/el5/x86_64/newrelic-repo-5-3.noarch.rpm' do
  not_if 'rpm -q newrelic-repo'
end

package 'newrelic-php5'

### Configuration Files ###
LICENSE_KEY = 'a77b75638b532e0510982afaeaf6f917244c3601'.freeze

execute "NR_INSTALL_SILENT=true NR_INSTALL_KEY=#{LICENSE_KEY} newrelic-install install"
