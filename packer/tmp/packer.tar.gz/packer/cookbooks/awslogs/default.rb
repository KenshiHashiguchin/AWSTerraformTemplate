# frozen_string_literal: true

### Install ###
package 'awslogs'

### Configuration Files ###
file '/etc/awslogs/awscli.conf' do
  action :edit
  block do |content|
    content.sub!('region = us-east-1', 'region = ap-northeast-1')
  end
end

remote_file '/etc/awslogs/awslogs.conf' do
  mode '0644'
  owner 'root'
  group 'root'
end
