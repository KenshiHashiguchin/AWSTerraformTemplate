# frozen_string_literal: true

### Install ###
remote_file '/usr/local/bin/env-aws-params' do
  mode '0775'
  owner 'root'
  group 'root'
end
