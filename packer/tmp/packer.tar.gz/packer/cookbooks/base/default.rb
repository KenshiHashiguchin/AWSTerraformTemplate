# frozen_string_literal: true

### Yum ###
execute 'yum clean all && yum -y update' do
  not_if 'yum check-update'
end

### TimeZone ###
execute 'timedatectl set-timezone Asia/Tokyo' do
  not_if 'timedatectl status | grep Asia/Tokyo'
end
