# frozen_string_literal: true

### Install ###
execute 'amazon-linux-extras install nginx1.12=1.12.2' do
  not_if 'type nginx > /dev/null'
end

### Configuration Files ###
remote_file '/etc/nginx/nginx.conf' do
  mode '0644'
  owner 'root'
  group 'root'
end

### Service ###
service 'nginx' do
  action %i[enable start]
end
