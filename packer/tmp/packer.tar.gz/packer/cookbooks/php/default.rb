# frozen_string_literal: true

### Install ###
execute 'amazon-linux-extras install php7.2=7.2.11' do
  not_if 'type php > /dev/null'
end

EXTENSIONS = %w[
  php-mbstring
  php-opcache
  php-soap
  php-xml
].freeze

EXTENSIONS.each do |extension|
  package extension
end

### Configuration Files ###
file '/etc/php.ini' do
  action :edit
  block do |content|
    content.sub!('expose_php = On', 'expose_php = Off')
  end
end

### Composer ###
execute 'curl -sS https://getcomposer.org/installer | php' do
  not_if 'type composer > /dev/null'
end

execute 'mv composer.phar /usr/local/bin/composer' do
  not_if 'test -e /usr/local/bin/composer'
end

execute 'chown root:root /usr/local/bin/composer' do
  not_if 'find /usr/local/bin/composer -user root -group root'
end

### PHP-FPM ###
file '/etc/php-fpm.d/www.conf' do
  action :edit
  block do |content|
    content.gsub!(/^((user|group) = )apache$/, '\1nginx')
    content.sub!(';clear_env = no', 'clear_env = no')
    content.sub!(';catch_workers_output = yes', 'catch_workers_output = yes')
    content.sub!(';access.log = log/$pool.access.log',
                 'access.log = /var/log/php-fpm/$pool.access.log')
  end
end

file '/lib/systemd/system/php-fpm.service' do
  action :edit
  block do |content|
    content.sub!('[Service]', "[Service]\nEnvironmentFile=/etc/sysconfig/php-fpm")
  end
end

file '/etc/sysconfig/php-fpm'

file '/etc/profile.d/sh.local' do
  action :edit
  block do |content|
    content << 'set -a; eval "$(cat /etc/sysconfig/php-fpm <(echo) <(declare -x))"; set +a;'
  end
end

### Service ###
service 'php-fpm' do
  action %i[enable start]
end
